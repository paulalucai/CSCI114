/**
 * CSCI 114 online, Week 2 Rectangles homework
 * 
 * @author: Paula Caixeta
 * @version: 01/20/15
 */

import java.awt.Rectangle;

public class Rectangles {
    public static void main(String[] args) {
        Rectangle rectangle1 = new Rectangle(0, 0, 10, 20);
        Rectangle rectangle2 = new Rectangle(5, 10, 20, 10);
        
        System.out.println("rectangle1: " + rectangle1);
        System.out.println("rectangle2: " + rectangle2);
        
        // shape representing the intersection of the first two rectangles created
        Rectangle rectangle3 = rectangle1.intersection(rectangle2);
        
        // the following rectangles do not intersect, but still creates a Rectangle shape
        Rectangle anotherRectangle = new Rectangle(100, 200, 10, 10);
        Rectangle noIntersection = rectangle1.intersection(anotherRectangle);
        
        System.out.println("noIntersection: " + noIntersection);
        
        // determines whether the shape is empty by returning a boolean value
        System.out.println("Is this rectangle empty? " + noIntersection.isEmpty());
    }
}
