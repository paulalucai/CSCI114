
/**
 * Lab 1. Car - CSCI 114, online class
 * 
 * @author Paula Caixeta 
 * @version 02/03/15
 */
public class Car {
   private double mpg; // fuel efficiency in miles per gallon
   private double gallons; // amount of gas in the tank in gallons
   
   /**
    * Constructor that creates a new Car object.
    * 
    * @param fuelEfficiency  efficiency in miles per gallon
    */
   public Car(double fuelEfficiency) {
       mpg = fuelEfficiency;
       gallons = 3.5;
   }
   
   /**
    * Increases amount of gas in the gas tank.
    * 
    * @param amount  amount of gas to add
    */
   public void addGas(double amount) {
       gallons += amount;
   }
   
   /**
    * Decreases the amount of gas in the gas tank.
    * 
    * @param distance  distance in miles
    */
   public void drive(double distance) {
       gallons -= (distance / mpg);
   }
   
   /**
    * Calculates the number of miles the car can travel until the gas tank is empty. 
    */
   public double range() {
       return mpg * gallons;
   }
}
